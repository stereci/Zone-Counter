package semih_tereci;
public interface ZoneCounterInterface {
    void Init(MapInterface map) throws Exception;//method isimleri küçük harfle başlamalı clean code prensipleri kapsamında
    int Solve() throws Exception;
}

